


public class Main {
    public static void main(String[] args) {
        // Creación de objetos
        Persona persona1 = new Persona("Juan", 25);
        Persona persona2 = new Persona("Ana", 16);

        // Uso de métodos
        persona1.mostrarInformacion();
        persona2.mostrarInformacion();

        // Verificar si son mayores de edad
        System.out.println("¿Juan es mayor de edad? " + persona1.esMayorDeEdad());
        System.out.println("¿Ana es mayor de edad? " + persona2.esMayorDeEdad());

        // Uso de sobrecarga de métodos
        persona1.saludar();
        persona2.saludar("¡Hola a todos!");
    }
}