
package java;

class ope{

 private String nombre;
 private int edad;

 public Persona(String nombre, int edad){

     this.nombre=nombre;
     this.edad=edad;
 }   

    public void mostrarInformacion(){

        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
    }
    public boolean esMayorDeEdad(){

        return edad >= 18;
    }

    public void saludar(){
        System.out.println("Hola, soy " + nombre);
    }
    public void saludar(String mensaje){
        System.out.println(mensaje + " Soy " + nombre);
    }

    
}